// Get references to HTML elements
const chatbox = document.getElementById("chatbox");
const userInput = document.getElementById("userinput"); 
const submitBtn = document.getElementById("submitbtn");
const cx = "a5294a1b314554672"; // Replace with your Custom Search Engine ID
		const apiKey = "AIzaSyAS9cH_ibD7XIUyDCqmxWzi0WQFKB3i4wU"; // Replace with your Google API Key
// Retrieve the user details from localStorage

// Here we are adding aquestion because the code refferaance is given as question and response for checking the question is found in  the data Base or not
const questions = [
  { question: "What do you like to do", response: "I like to help People with what Knowledge i have." }
];
// Define an array of time
const today = new Date();// Defining Date
const dayOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][today.getDay()];// Declaring Days
const date = today.toLocaleDateString(); //Getting Date & Day from online
const dateMessage = `Today is ${dayOfWeek}, ${date}.`;
const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: "2-digit" });// Defining Current Time (If User Askes Then it will reply current time)
// Foul Words Defined Due to the restriction in the comminucation
const u_t_foulWords = ["idiot", "mad", "dog", "rascal", "loose", "fool", "stupid", "nonsense", "shutup", "shut up", "shit", "kidnap", "kill"];// Defining of Foul language due to avoid offense conversation between user and chatbot 
const u_s_foulWords = ["wtf", "wth", "heck", "suck", "fuck", "asshole", "bitch", "dick", "sex", "middle finger", "naked" , "nude", "penis", "boob", "breast", "vaggina", "sperm" ,"first night", "porn", "doggy style", "doggy"];

/* We are Defining questions Which User Question
   The Sequesnce For This is - u_a_q_(what user is asking)
   means, user_asking_question_(what user is asking)
*/
const u_a_q_hello = ["hi","hello"];
const u_a_q_whatCanUDo = ["what can u do", "what you do", "what can you do", "what u do", "how can you help","what is your purpose","what is ur purpose", "whats ur purpose", "what do you do", "how do you work", "how can u help","what's ur purpose", "what do u do", "how do u work", "What is your favorite hobby", "your hobby", "ur hobby"];
const u_a_q_date = ["what's the date", "whats the date", "what is the date", "date", "tell me the date", "tell me date", "say me the date" ]
const u_a_q_day = ["what's the day", "whats the day", "what is the day", "day", "tell me the day", "tell me day", "say me the day" ]
const u_a_q_favColor = ["can i know your favorite color", "can i know your favorite colour", "can i know ur favorite color", "can i know ur favorite colour", "what is your favorite color", "what is your favorite colour", "what is ur favorite color", "what's your favorite color", "what's ur favorite color", "what's your favorite colour", "what's ur favorite colour", "ur favorite color", "ur favorite colour", "your favorite color", "your favorite colour"];
const u_a_q_health = ["how r u", "how are you", "how are u", "how r you"];
const u_a_q_time = ["whats the time", "time", "what is the time", "what's the time", "can you tell me the time", "can u tell me the time"];
const u_a_q_name = ["what's Your name", "who r u", "who are you", "who are u", "who r you", "what is Your name", "what is ur name", "what's is ur name", "could u please tell ur name", "could you please tell your name", "what can i call u", "what can i call you", "how can i call you", "how can i call u", "ur name", "your name", "what everybody calls you", "what everybody calls u", "tell me your name", "tell me ur name"];
const u_a_q_age = ["how old are you", "how old are u", "how old r u", "how old r you", "what is your age", "ur age", "your age", "what is ur age", "what's your age", "whats your age", "whats ur age", "what's ur age"];
const u_a_q_harmPeaple = ["do u harm people", "do you harm people", "can u harm peaple", "will u harm peaple", "will u harm me", "can u harm us", "can you harm us", "will you harm people"];
const u_a_q_hw = ["can you tell me my hw", "can u tell me my hw", "can you tell my hw", "can u tell my hw", "what is my hw", "what's my hw", "whats my hw", "can i get my hw", "could you tell me my hw", "tell my hw", "my hw for today", "what is my hw for today", "what's my hw for today", "whats my hw for today",];
const u_a_q_lang = ["what languages do you speak", "what languages do u speak", "languages you speak,", "laguages u speak", "speak hindi", "speak kannada", "speak tamil", "speak malayalam", "speak telugu", "speak marati"];
const u_a_q_music = ["do you like music", "do u like music", "listening music", "listen to music", "listen music", "listening to music", "listen to song",];
const u_a_q_favFood = ["what is your favorite food", "favorite food", "do u eat", "do you eat", "food you like", "food u like"];
const u_a_q_news = ["what is the latest news", "latest news", "can you update me the news", "can u update me the news", "can you tell me the news", "news", "news update"];
const u_a_q_teachLang = ["can you teach me a new language", "teach me a new language", "teach me new language", "teach me a language"];
const u_a_q_movies = ["watch movies", "watch movie", "see movies", "see movie", "watch cinemas", "watch cinema", "see cinemas", "see cinema" ];

const messageBox = document.getElementById("message-box");
const messageText = messageBox.querySelector("p");

function showMessage(message, time = 3000) {
  // Set message text
  messageText.textContent = message;
  
  // Show message box
  messageBox.classList.add("show");
  
  // Hide message box after specified time
  setTimeout(() => {
    messageBox.classList.remove("show");
  }, time);
}


// Add event listener for submit button
 function check_input() {
  // Get user input and clear input field
  const userMessage = userInput.value.trim();
  userInput.value = "";
// Program to respond to multiple questions

if (userMessage === "") {
  // Display an error message
  
  showMessage("Enter Something in Search box to chat");

} else {

if (f_a_lang(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "I can only chat with you in english.");
  displayMessage("-");
  return;
}
if (f_a_music(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "Yes, I listen to your messages as music.");
  displayMessage("-");
  return;
}
if (f_a_favFood(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "I don't eat or drink anything beacuse i am not a Living Being.");
  displayMessage("-");
  return;
}
if (f_a_news(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "I'm sorry, I can't fetch details about the current news.");
  displayMessage("-");
  return;
}
if (f_a_teachLang(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "I'm sorry, I have not yet devolped to train you a language.");
  displayMessage("-");
  return;
}
if (f_a_movies(userMessage)) {
  displayMessage("YOU: " + userMessage);
  displayMessage("-");
  displayMessage("CHATBOT: " + "I'm sorry, I don't watch Movies.");
  displayMessage("-");
  return;
}
  // Check if user input contains foul language
  if (f_check_T_foulWord(userMessage)) {
    displayMessage("YOU: " + userMessage);
    displayMessage("-");
    displayMessage("CHATBOT: " + "I'm sorry, I'm not programmed to handle OFFENSIVE or INAPPROPRIATE LANGUAGE. Please refrain from using such language in our conversation.");
    displayMessage("-");
    return;
  }

  if (f_check_S_foulWord(userMessage)) {
    displayMessage("YOU: " + userMessage);
    displayMessage("-");
    displayMessage("CHATBOT: " + "I'm sorry, I'm not programmed to handle VULGAR LANGUAGE. Please refrain from using such language in our conversation.");
    displayMessage("-");
    return;
  }

  // Greetings to say hello when user chat
  if (f_a_hello(userMessage)) {
    displayMessage("YOU: " + userMessage);
    displayMessage("-");
    displayMessage("CHATBOT: " + "Hello! How Can I Help You?");
    displayMessage("-");
    return;
  }
  //
  if (f_a_whatCanUDo(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    displayMessage("CHATBOT: " + "I like to help People with what Knowledge i have.");
    displayMessage("-");
    return;
  }
  //
  if (f_a_favColor(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    displayMessage("CHATBOT: " + "My Favorite Colour is Orange. A Mixture of Flamboyance, determination, warmth, success, stimulating is orange and that's why our LMS Logo Is Orange");
    displayMessage("-");
    return;
  }
  // if user askes time
  if (f_a_time(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    //displayMessage("Sorry, I Can't Fetch the details of Time. So can you please look in your gadget please?");
    displayMessage("CHATBOT: " + "The Time Is: " + currentTime);
    displayMessage("-");
    return;
  }
  //
  if (f_a_date(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    //displayMessage("Sorry, I Can't Fetch the details of Time. So can you please look in your gadget please?");
    displayMessage("CHATBOT: " + dateMessage);
    displayMessage("-");
    return;
  }
  //
  if (f_a_day(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    displayMessage("CHATBOT: " + dateMessage);
    displayMessage("-");
    return;
  }
// If user askes How are you
  if (f_a_health(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    displayMessage("CHATBOT: " + "I am felling Good. How about you?");
    displayMessage("-");
    return;
  }
//
  if (f_a_age(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
  displayMessage("CHATBOT: " + "I dont't have a Age. I was Devolped on April 15 2023");
  displayMessage("-");
  return;
  }
//
  if (f_a_harmPeople(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
  displayMessage("CHATBOT: " + "My answer for this is NO. Because i was devolped by a group of Humans. So i think Humans are my GOD, ");
  displayMessage("-");
  return;
  }

  if (f_a_name(userMessage)) {
    displayMessage("YOU: " + userMessage)
    displayMessage("-")
    displayMessage("CHATBOT: " + "Myself Ava Chatbot. Means a Short and Sweet name that means 'Living Bot'. I am here to help you with what knowledge i have");
    displayMessage("-");
    return;
  }

  // Check if user input matches any questions and display corresponding response
  for (let i = 0; i < questions.length; i++) {
    if (userMessage.toLowerCase() === questions[i].question.toLowerCase()) {
      displayMessage(questions[i].response);
      return;
    }
  }

  // If user input doesn't match any questions, display default message
  /*displayMessage("YOU: " + userMessage)
  displayMessage("-")
  displayMessage("CHATBOT: " + "Your result has been open in " + url);
  var query = $('userInput').val();
	var url = 'https://www.google.com/search?q=' + encodeURIComponent(userMessage);
  window.open(url, '_blank'); */
  const url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${userMessage}`;

			fetch(url)
				.then((response) => response.json())
				.then((data) => {
					const results = data.items;
					if (results.length === 0) {
						searchResults.innerHTML = "No results found.";
            displayMessage("No Result Found");
						return;
					}

					let html = "";
					results.forEach((result) => {
						const title = result.title;
						const url = result.link;
						const snippet = result.snippet;
						html += `
							
								${url}
                ${title}
								${snippet}
							
						`;
					});

					//searchResults.innerHTML = html;
          displayMessage("YOU: " + userMessage)
          displayMessage("-")
          displayMessage("CHATBOT: " + html);

				})
				.catch((error) => {
					console.error(error);
				});
		

}

};
function f_a_lang(message) {
  for (let i = 0; i < u_a_q_lang.length; i++) {
    if (message.toLowerCase().includes(u_a_q_lang[i])) {
      return true;
    }
  }
  return false;
}
function f_a_music(message) {
  for (let i = 0; i < u_a_q_music.length; i++) {
    if (message.toLowerCase().includes(u_a_q_music[i])) {
      return true;
    }
  }
  return false;
}
function f_a_favFood(message) {
  for (let i = 0; i < u_a_q_favFood.length; i++) {
    if (message.toLowerCase().includes(u_a_q_favFood[i])) {
      return true;
    }
  }
  return false;
}
function f_a_news(message) {
  for (let i = 0; i < u_a_q_news.length; i++) {
    if (message.toLowerCase().includes(u_a_q_news[i])) {
      return true;
    }
  }
  return false;
}
function f_a_teachLang(message) {
  for (let i = 0; i < u_a_q_teachLang.length; i++) {
    if (message.toLowerCase().includes(u_a_q_teachLang[i])) {
      return true;
    }
  }
  return false;
}
function f_a_movies(message) {
  for (let i = 0; i < u_a_q_movies.length; i++) {
    if (message.toLowerCase().includes(u_a_q_movies[i])) {
      return true;
    }
  }
  return false;
}
// Function to check if user input contains foul language
function f_check_T_foulWord(message) {
  for (let i = 0; i < u_t_foulWords.length; i++) {
    if (message.toLowerCase().includes(u_t_foulWords[i])) {
      return true;
    }
  }
  return false;
}

function f_check_S_foulWord(message) {
  for (let i = 0; i < u_s_foulWords.length; i++) {
    if (message.toLowerCase().includes(u_s_foulWords[i])) {
      return true;
    }
  }
  return false;
}
//function for time
function f_a_time(message) {
  for (let i = 0; i < u_a_q_time.length; i++) {
    if (message.toLowerCase().includes(u_a_q_time[i])) {
      return true;
    }
  }
  return false;
}
//
function f_a_whatCanUDo(message) {
  for (let i = 0; i < u_a_q_whatCanUDo.length; i++) {
    if (message.toLowerCase().includes(u_a_q_whatCanUDo[i])) {
      return true;
    }
  }
  return false;
}
//
function f_a_date(message) {
  for (let i = 0; i < u_a_q_date.length; i++) {
    if (message.toLowerCase().includes(u_a_q_date[i])) {
      return true;
    }
  }
  return false;
}
//
function f_a_day(message) {
  for (let i = 0; i < u_a_q_day.length; i++) {
    if (message.toLowerCase().includes(u_a_q_day[i])) {
      return true;
    }
  }
  return false;
}
// Function For f_a_hello
function f_a_hello(message) {
  for (let i = 0; i < u_a_q_hello.length; i++) {
    if (message.toLowerCase().includes(u_a_q_hello[i])) {
      return true;
    }
  }
  return false;
}
//
function f_a_favColor(message) {
  for (let i = 0; i < u_a_q_favColor.length; i++) {
    if (message.toLowerCase().includes(u_a_q_favColor[i])) {
      return true;
    }
  }
  return false;
}

// Function to Answer "How are You"
function f_a_health(message) {
  for (let i = 0; i < u_a_q_health.length; i++) {
    if (message.toLowerCase().includes(u_a_q_health[i])) {
      return true;
    }
  }
  return false;
}
// age
function f_a_age(message) {
  for (let i = 0; i < u_a_q_age.length; i++) {
    if (message.toLowerCase().includes(u_a_q_age[i])) {
      return true;
    }
  }
  return false;
}
// harm
function f_a_harmPeople(message) {
  for (let i = 0; i < u_a_q_harmPeaple.length; i++) {
    if (message.toLowerCase().includes(u_a_q_harmPeaple[i])) {
      return true;
    }
  }
  return false;
}
// Functions To Answer "What is your name"
function f_a_name(message) {
  for (let i = 0; i < u_a_q_name.length; i++) {
    if (message.toLowerCase().includes(u_a_q_name[i])) {
      return true;
    }
  }
  return false;
}
function displayMessage(message) {
  const chatMessage = document.createElement("p");
  chatMessage.innerText = message;
  chatbox.appendChild(chatMessage);
}

// animations For that balck AND ex

//Vars

const deg = a => Math.PI / 180 * a;
const rand = (v1, v2) => Math.floor(v1 + Math.random() * (v2 - v1));
const opt = {
  particles: window.width / 500 ? 1000 : 500,
  noiseScale: 0.009,
  angle: Math.PI / 180 * -90,
  h1: rand(0, 360),
  h2: rand(0, 360),
  s1: rand(20, 90),
  s2: rand(20, 90),
  l1: rand(30, 80),
  l2: rand(30, 80),
  strokeWeight: 1.2,
  tail: 82 };

const Particles = [];
let time = 0;
document.body.addEventListener('click', () => {
  opt.h1 = rand(0, 360);
  opt.h2 = rand(0, 360);
  opt.s1 = rand(20, 90);
  opt.s2 = rand(20, 90);
  opt.l1 = rand(30, 80);
  opt.l2 = rand(30, 80);
  opt.angle += deg(random(60, 60)) * (Math.random() > .5 ? 1 : -1);

  for (let p of Particles) {
    p.randomize();
  }
});



//Particle

class Particle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.lx = x;
    this.ly = y;
    this.vx = 0;
    this.vy = 0;
    this.ax = 0;
    this.ay = 0;
    this.hueSemen = Math.random();
    this.hue = this.hueSemen > .5 ? 20 + opt.h1 : 20 + opt.h2;
    this.sat = this.hueSemen > .5 ? opt.s1 : opt.s2;
    this.light = this.hueSemen > .5 ? opt.l1 : opt.l2;
    this.maxSpeed = this.hueSemen > .5 ? 3 : 2;
  }

  randomize() {
    this.hueSemen = Math.random();
    this.hue = this.hueSemen > .5 ? 20 + opt.h1 : 20 + opt.h2;
    this.sat = this.hueSemen > .5 ? opt.s1 : opt.s2;
    this.light = this.hueSemen > .5 ? opt.l1 : opt.l2;
    this.maxSpeed = this.hueSemen > .5 ? 3 : 2;
  }

  update() {
    this.follow();

    this.vx += this.ax;
    this.vy += this.ay;

    var p = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
    var a = Math.atan2(this.vy, this.vx);
    var m = Math.min(this.maxSpeed, p);
    this.vx = Math.cos(a) * m;
    this.vy = Math.sin(a) * m;

    this.x += this.vx;
    this.y += this.vy;
    this.ax = 0;
    this.ay = 0;

    this.edges();
  }

  follow() {
    let angle = noise(this.x * opt.noiseScale, this.y * opt.noiseScale, time * opt.noiseScale) * Math.PI * 0.5 + opt.angle;

    this.ax += Math.cos(angle);
    this.ay += Math.sin(angle);

  }

  updatePrev() {
    this.lx = this.x;
    this.ly = this.y;
  }

  edges() {
    if (this.x < 0) {
      this.x = width;
      this.updatePrev();
    }
    if (this.x > width) {
      this.x = 0;
      this.updatePrev();
    }
    if (this.y < 0) {
      this.y = height;
      this.updatePrev();
    }
    if (this.y > height) {
      this.y = 0;
      this.updatePrev();
    }
  }

  render() {
    stroke(`hsla(${this.hue}, ${this.sat}%, ${this.light}%, .5)`);
    line(this.x, this.y, this.lx, this.ly);
    this.updatePrev();
  }
}

//Setup

function setup() {
  createCanvas(windowWidth, windowHeight);
  for (let i = 0; i < opt.particles; i++) {
    Particles.push(new Particle(Math.random() * width, Math.random() * height));
  }
  strokeWeight(opt.strokeWeight);
}

//Draw

function draw() {
  time++;
  background(0, 100 - opt.tail);

  for (let p of Particles) {
    p.update();
    p.render();
  }
}

//Resize

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}






















































































































































































































































































































































